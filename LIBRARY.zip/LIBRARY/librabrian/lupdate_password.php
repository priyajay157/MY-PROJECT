<?php
	
	session_start();
	if(!isset($_SESSION['name']))
	{
	   header('location:../index.php');
	}
	include("../connection.php");
	$password = "";
	$query = "select * from librarians where email = '$_SESSION[email]'";
	$query_run = mysqli_query($conn,$query);
	while ($row = mysqli_fetch_assoc($query_run)){
		$password = $row['password'];
	}
	if($password == $_POST['old_password']){
		$query = "update librarians set password = '$_POST[new_password]' where email = '$_SESSION[email]'";
		$query_run = mysqli_query($conn,$query);
		?>
		<script type="text/javascript">
			alert("Updated successfully...");
			window.location.href = "librabrian_dashboard.php";
		</script>
		<?php
	}
	else{
		?>
		<script type="text/javascript">
			alert("Wrong Admin Password...");
			window.location.href = "lchange_password.php";
		</script>
		<?php
	}
?>
