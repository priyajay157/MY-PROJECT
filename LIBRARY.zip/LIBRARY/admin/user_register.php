<?php
session_start();
if(!isset($_SESSION['name']))
{
   header('location:../index.php');
}
include("../connection.php");

$query = "insert into users values(null,'$_POST[name]','$_POST[email]','$_POST[password]','$_POST[mobile]','$_POST[address]')";
$query_run = mysqli_query($conn,$query);
?>
<script>
    alert("Registration Successfully.......You may login now.")
    window.location.href="admin_dashboard.php";
</script>
