<?php
	//require("functions.php");
	session_start();
	if(!isset($_SESSION['name']))
	{
	   header('location:../index.php');
	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard</title>
	<meta charset="utf-8" name="viewport" content="width=device-width,intial-scale=1">
	<link rel="stylesheet" type="text/css" href="../bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="../bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="../bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
	<a href="admin_dashboard.php">GO Back</a>
        <center><h3>Librabrian Registration Form</h3></center>
       <form action="" method="post" >
            <div class="form-group">
                <label for="name">Full Name:</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="name">Eamil ID:</label>
                <input type="text" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="name">Password:</label>
                <input type="password" name="password" class="form-control" required>
            </div>
            <div class="form-group">
                <label for="name">Mobile Number:</label>
                <input type="text" name="mobile" class="form-control" required>
            </div>
           
            <button type="submit" class="btn btn-primary" name="save_btn">Register</button>
        </form>
        <?php
        include("../connection.php");
        if(isset($_POST['save_btn'])){
            $name=$_POST['name'];
            $email=$_POST['email'];
            $password=$_POST['password'];
            $mobile=$_POST['mobile'];

            $query="INSERT INTO `librarians`(`name`,`email`,`password`,`mobile`)VALUES('$name','$email','$password','$mobile')";
            $query_run=mysqli_query($conn,$query);
            if( $query_run){
                ?>
                <script>
                    alert("Librarian Registration Successfully");
                    window.open("http://localhost/LIBRARY/admin/admin_dashboard.php","_self")
                </script>
                <?php
            }


        }
        ?>
    
    

    
</body>
</html>
