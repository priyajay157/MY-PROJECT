<?php
session_start();
if(!isset($_SESSION['name']))
{
   header('location:../index.php');
}
	include("../connection.php");
	$query = "delete from books where book_no = $_GET[bn]";
	$query_run = mysqli_query($conn,$query);
?>
<script type="text/javascript">
	alert("Book Deleted successfully...");
	window.location.href = "manage_book.php";
</script>