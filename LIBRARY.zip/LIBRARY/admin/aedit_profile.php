<?php
session_start();
if(!isset($_SESSION['name']))
{
   header('location:../index.php');
}
include("../connection.php");
 $id=$_GET['id'];
$select = "SELECT * FROM admins WHERE id='$id'";
$query_run = mysqli_query($conn,$select);
$row=mysqli_fetch_array($query_run);
?>
<!DOCTYPE html>
<!DOCTYPE html>
<html lang="en">
<head>
	<a href="admin_dashboard.php">GO Back</a>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Dashboard</title>
    <meta charset="utf-8" name="viewport" content="width=device-width,intial-scale=1">
	<link rel="stylesheet" type="text/css" href="../bootstrap-4.4.1/css/bootstrap.min.css">
  	<script type="text/javascript" src="../bootstrap-4.4.1/js/juqery_latest.js"></script>
  	<script type="text/javascript" src="../bootstrap-4.4.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="row">
			<div class="col-md-4"></div>
			<div class="col-md-4">
				<form action="" method="post">
					<div class="form-group">
						<label for="name">Name:</label>
						<input type="text" class="form-control" name="name" value="<?php echo $row['name']?>" >
					</div>
					<div class="form-group">
						<label for="email">Email:</label>
						<input type="text" name="email" value="<?php echo $row['email']?>" class="form-control" >
					</div>
					<div class="form-group">
						<label for="mobile">Mobile:</label>
						<input type="text" name="mobile" value="<?php echo $row['mobile']?>" class="form-control" >
					</div>
					
					<input type="submit" name="update_btn" value="Update">
				</form>
			</div>
			<div class="col-md-4"></div>
		</div>
	</center>


    <?php

if(isset($_POST['update_btn'])){
    $name=$_POST['name'];
    $email=$_POST['email'];
    $mobile=$_POST['mobile'];

 
$update="UPDATE `admins` SET `name`='$name',`email`='$email',`mobile`='$mobile' WHERE id='$id'";
$query_run=mysqli_query($conn,$update);
if($query_run){
    ?>
    <script>
        alert("Record Update");
		window.open("http://localhost/LIBRARY/admin/admin_dashboard.php","_self");
  
        
    </script>
    <?php
    
}
else{
    ?>
    <script>
        alert("No Record Updated");
		window.open("http://localhost/LIBRARY/admin/aedit_profile.php","_self");
  
    </script>
    <?php

}

}

?>
    
</body>
</html>