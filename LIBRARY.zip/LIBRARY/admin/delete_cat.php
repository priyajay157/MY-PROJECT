<?php
session_start();
if(!isset($_SESSION['name']))
{
   header('location:../index.php');
}
	include("../connection.php");
	$query = "delete from category where cat_id = $_GET[cid]";
	$query_run = mysqli_query($conn,$query);
?>
<script type="text/javascript">
	alert("Category Deleted successfully...");
	window.location.href = "manage_cat.php";
</script>